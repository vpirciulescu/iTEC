#pragma once

#include <Game/iTEC/iTECpanda.h>
#include <Game/iTEC/iTECpanda_Vis2D.h>
