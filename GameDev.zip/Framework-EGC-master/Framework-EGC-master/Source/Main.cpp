#include <ctime>
#include <iostream>
#include <Windows.h>
#include <MMSystem.h>
#include <playsoundapi.h>
#include <time.h>

using namespace std;

#include <Core/Engine.h>
#include <opencv2/opencv.hpp>
#include <Game/LabList.h>

using namespace cv;

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));

	// Create a window property structure
	WindowProperties wp;
	wp.resolution = glm::ivec2(1280, 720);


		// Init the Engine and create a new window with the defined properties
		WindowObject* window = Engine::Init(wp);

		// Create a new 3D world and start running it
		Mat frame;
		string path = "C:\\Pandahorror.avi";

		VideoCapture capture(path);
		namedWindow("Horror Video");

		clock_t time_begin;
		clock_t time_end;

		time_begin = clock();
		time_end = clock();
		cout << time_begin / CLOCKS_PER_SEC;


		while (((time_end - time_begin)/CLOCKS_PER_SEC) < 6) {
			capture >> frame;
			imshow("Horror Video", frame);
			if (waitKey(30) >= 0)
				break;
			time_end = clock();						
		}

		World *world = new iTECpanda();
		world->Init();
		world->Run();

	Engine::Exit();

	return 0;
}