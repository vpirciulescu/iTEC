#include "iTECpanda.h"

#include <vector>
#include <iostream>
#include <map>
#include <opencv2/opencv.hpp>

#include <Windows.h>
#include <MMSystem.h>
#include <playsoundapi.h>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace cv;

struct position {
	float x, y;
	bool exista;
	float scale;
};

using namespace std;
using namespace cv;

int nr_piese;
position poz[97];
string nr[11] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11" };
float rotateangle = 0;
float posx = 150, posy = 250;
float trspeed = 2;
float scaleX = 1, scaleY = 1;
float speedY = 450, speedX = 550;
float rectangleWidth;
float rectangleHeight;
int click = 0;
int nr_vieti = 3;
int lungime_platforma = 200;
int sus = 0;
int i, j;
int directie; 
int linie = 20, coloana = 20;
string name;
float patratX;
float patratY;
float angle = 0.0f;
float radius = 10;
int pas = 0;
bool powerup = false;
float timePowerup = 100;
int nr_vieti_panda = 6;
int nr_bricks_deleted = 0;

iTECpanda::iTECpanda()
{
}

iTECpanda::~iTECpanda()
{
}

void iTECpanda::Init()
{

	
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);
	rectangleWidth = 70;
	rectangleHeight = 35;
	

	// initialize tx and ty (the translation steps)
	translateX = 0;
	translateY = 0;

	// initialize sx and sy (the scale factors)
	scaleX = 1;
	scaleY = 1;

	// initialize angularStep
	angularStep = 0;

	//creare meshuri pt caramizi, pereti, platforma, vietii si bila
	Mesh** square = (Mesh**)malloc(78*sizeof(Mesh*));

	//caramizi
	nr_piese = 8;
	for (i = 0; i < 8; i++)
		for (j = 0; j < 10; j++) {

			name.clear();
			poz[nr_piese].x = 150 + j * 2 * 46;
			poz[nr_piese].y = 600 - i * 52;
			poz[nr_piese].exista = true;
			poz[nr_piese].scale = 1;
			nr_piese++;
			corner = glm::vec3(150 + j * 2 * 46, 600 - i * 52, 0);
			name = "caramida" + nr[i] + nr[j];
			square[i*7+j] = Object2D::CreateRectangle(name, corner, rectangleHeight, rectangleWidth, glm::vec3(1, 1, 1), true);
			AddMeshToList(square[i*7+j]);
		}

	//corpPanda
	rectangleHeight = 100;
	rectangleWidth = 80;
	corner = glm::vec3(window->GetResolution().x - 130, 50, 0);
	Mesh* corpPanda = Object2D::CreateRectangle("corpPanda", corner, rectangleHeight, rectangleWidth, glm::vec3(1, 1, 1), true);

	AddMeshToList(corpPanda);
	corner = glm::vec3(window->GetResolution().x - 90, 100, 0);
	radius = 25;
	Mesh* cerc1 = Object2D::CreateCircle("cerc1", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(cerc1);

	corner = glm::vec3(window->GetResolution().x - 90, 110, 0);
	radius = 25;
	Mesh* cerc2 = Object2D::CreateCircle("cerc2", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(cerc2);

	//capPanda
	corner = glm::vec3(window->GetResolution().x - 90, 180, 0);
	radius = 40;
	Mesh* capPanda = Object2D::CreateCircle("capPanda", corner, radius, glm::vec3(1, 1, 1), true);
	AddMeshToList(capPanda);

	//ochii
	corner = glm::vec3(window->GetResolution().x - 110, 190, 0);
	radius = 10;
	Mesh* eyeLeft = Object2D::CreateCircle("eyeLeft", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(eyeLeft);

	corner = glm::vec3(window->GetResolution().x - 70, 190, 0);
	radius = 10;
	Mesh* eyeRight = Object2D::CreateCircle("eyeRight", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(eyeRight);

	//urechi
	corner = glm::vec3(window->GetResolution().x - 110, 212, 0);
	radius = 20;
	Mesh* urL = Object2D::CreateCircle("urL", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(urL);

	corner = glm::vec3(window->GetResolution().x - 70, 212, 0);
	radius = 20;
	Mesh* urR = Object2D::CreateCircle("urR", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(urR);

	//piciorStang
	corner = glm::vec3(window->GetResolution().x - 115, 40, 0);
	radius = 15;
	Mesh* piciorStang = Object2D::CreateCircle("piciorStang", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(piciorStang);

	//piciorDrept
	corner = glm::vec3(window->GetResolution().x - 65, 40, 0);
	radius = 15;
	Mesh* piciorDrept = Object2D::CreateCircle("piciorDrept", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(piciorDrept);

	//manaStanga
	corner = glm::vec3(window->GetResolution().x - 140, 120, 0);
	radius = 15;
	Mesh* manaStanga = Object2D::CreateCircle("manaStanga", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(manaStanga);

	//manaDrepta
	corner = glm::vec3(window->GetResolution().x - 40, 120, 0);
	radius = 15;
	Mesh* manaDreapta = Object2D::CreateCircle("manaDreapta", corner, radius, glm::vec3(0, 0, 0), true);
	AddMeshToList(manaDreapta);

	//perete stanga
	rectangleHeight = window->GetResolution().y - 50;
	rectangleWidth = 20;
	poz[4].x = 0;
	poz[4].y = 50;
	corner = glm::vec3(0, 50, 0);
	Mesh* pereteStanga = Object2D::CreateRectangle("pereteStanga", corner, rectangleHeight, rectangleWidth, glm::vec3(0.04f, 0.06f, 0.19f), true);
	AddMeshToList(pereteStanga);

	//perete sus
	rectangleWidth = window->GetResolution().x;
	rectangleHeight = 20;
	poz[5].x = 0;
	poz[5].y = window->GetResolution().y - rectangleHeight;
	corner = glm::vec3(0, window->GetResolution().y - rectangleHeight, 0);
	Mesh* pereteSus = Object2D::CreateRectangle("pereteSus", corner, rectangleHeight, rectangleWidth, glm::vec3(0.04f, 0.06f, 0.19f), true);
	AddMeshToList(pereteSus);

	//perete jos
	rectangleWidth = window->GetResolution().x;
	rectangleHeight = 10;
	poz[5].x = 0;
	poz[5].y = 0;
	corner = glm::vec3(0, 0, 0);
	Mesh* pereteJos = Object2D::CreateRectangle("pereteJos", corner, rectangleHeight, rectangleWidth, glm::vec3(0.04f, 0.06f, 0.19f), true);
	AddMeshToList(pereteJos);


	//perete dreapta
	rectangleHeight = window->GetResolution().y - 50;
	rectangleWidth = 20;
	poz[6].x = window->GetResolution().x - rectangleWidth;
	poz[6].y = 50;
	corner = glm::vec3(window->GetResolution().x - rectangleWidth, 50, 0);
	Mesh* pereteDreapta = Object2D::CreateRectangle("pereteDreapta", corner, rectangleHeight, rectangleWidth, glm::vec3(0.04f, 0.06f, 0.19f), true);
	AddMeshToList(pereteDreapta);

	//platforma
	rectangleHeight = 15;
	rectangleWidth = 200;
	poz[7].x = 0;
	poz[7].y = 0;
	corner = glm::vec3(550, 0, 0);
	Mesh* platforma = Object2D::CreateRectangle("platforma", corner, rectangleHeight, rectangleWidth, glm::vec3(1, 1, 1), true);
	AddMeshToList(platforma);

	//bile 
	radius = 10;
	corner = glm::vec3(650, 25, 0);
	Mesh* circle = Object2D::CreateCircle("circle", corner, radius, glm::vec3(1, 1, 1), true);
	poz[0].x = 0;
	poz[0].y = 0;
	AddMeshToList(circle);

	corner = glm::vec3(30, 20, 0);
	Mesh* circle1 = Object2D::CreateCircle("circle1", corner, radius, glm::vec3(1, 1, 1), true);
	poz[1].x = 30;
	poz[1].y = 20;
	AddMeshToList(circle1);

	corner = glm::vec3(60, 20, 0);
	Mesh* circle2 = Object2D::CreateCircle("circle2", corner, radius, glm::vec3(1, 1, 1), true);
	poz[2].x = 60;
	poz[2].y = 20;
	AddMeshToList(circle2);

	corner = glm::vec3(90, 20, 0);
	Mesh* circle3 = Object2D::CreateCircle("circle3", corner, radius, glm::vec3(1, 1, 1), true);
	poz[3].x = 60;
	poz[3].y = 20;
	AddMeshToList(circle3);
           	
	//cerc - powerup
	rectangleHeight = 20;
	rectangleWidth = 20;
	corner = glm::vec3(0, 0, 0);
	Mesh* powerUp = Object2D::CreateSquare("powerUp", corner, rectangleHeight, glm::vec3(0, 1, 0), true);
	AddMeshToList(powerUp);
}

void iTECpanda::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 181, 255, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void iTECpanda::CollisionBrick() {

	//nr_piese = 7;
	rectangleWidth = 35;
	rectangleHeight = 17.5;
	float nx, ny;
	float cx, cy;
	float dx, dy;
	name.clear();
	for (i = 0; i < 8; i++) {
		for (j = 0; j < 10; j++) {

			nr_piese = 8 + (i * 10 + j);
			nx = poz[nr_piese].x - 600 - rectangleWidth;
			ny = poz[nr_piese].y;
			//jos
			cy = poz[0].y + radius;
			cx = poz[0].x;
			dy = fabs(ny - cy);

			if ((dy >= 0) && (dy < 5.0f) && (cx >= nx) && (cx <= nx + 2*rectangleWidth)) {
				name.clear();
				if (poz[nr_piese].exista) {
					name = "caramida" + nr[i] + nr[j];
					meshes.erase(name);
					nr_bricks_deleted++;
					directie = -1;
					poz[nr_piese].exista = false;
					linie = i;
					coloana = j;
					if (i % 2) {
						patratX = poz[nr_piese].x + 20;
						patratY = poz[nr_piese].y;
					}
						directie = -1;
						poz[nr_piese].scale = 0.9;
					break;
				}
			}
			
			//sus
			cy = poz[0].y - radius;
			cx = poz[0].x;
			dy = fabs(ny - cy);

			if ((dy >= 0) && (dy < 5.0f) && (cx >= nx) && (cx <= (nx + 2 * rectangleWidth))) {
				name.clear();
				if (poz[nr_piese].exista) {
					name = "caramida" + nr[i] + nr[j];
					meshes.erase(name);
					directie = -1;
					poz[nr_piese].exista = false;
					linie = i;
					coloana = j;
					if (i % 2) {
						patratX = poz[nr_piese].x + 20;
						patratY = poz[nr_piese].y;
					}
					directie = 1;
					break;
				}
			}

			//stanga
			cy = poz[0].y;
			cx = poz[0].x + radius;
			dy = fabs(ny - cy);

			if ((dy >= 0) && (dy < 5.0f) && (cx >= (nx - rectangleHeight)) && (cx <= (nx + rectangleHeight))) {
				name.clear();
				if (poz[nr_piese].exista) {
					name = "caramida" + nr[i] + nr[j];
					meshes.erase(name);
					directie = -1;
					poz[nr_piese].exista = false;
					linie = i;
					coloana = j;
					if (i % 2) {
						patratX = poz[nr_piese].x + 20;
						patratY = poz[nr_piese].y;
					}
					directie = -2;
					break;
				}
			}

			//dreapta
			cy = poz[0].y;
			cx = poz[0].x - radius;
			dy = fabs(ny - cy);

			if ((dy >= 0) && (dy < 5.0f) && (cx >= (nx - rectangleHeight)) && (cx <= (nx + rectangleHeight))) {
				name.clear();
				if (poz[nr_piese].exista) {
					name = "caramida" + nr[i] + nr[j];
					meshes.erase(name);
					directie = -1;
					poz[nr_piese].exista = false;
					linie = i;
					coloana = j;
					if (i % 2) {
						patratX = poz[nr_piese].x + 20;
						patratY = poz[nr_piese].y;
					}
					directie = -3;
					break;
				}
			}

		}
		if (name.size())
			break;
	}
 
}

void iTECpanda::Collision() {

	//bila - perete sus
	if (poz[0].y > window->GetResolution().y - 40)
		directie = -1;

	//bila - perete stanga
	if ((poz[0].x < -600) && (poz[0].y > 5)){
		directie = -2;
	}
		
	//bila - perete dreapta
	if ((poz[0].y > 5) && (poz[0].x > 610)) {
		directie = -3;
	}

	//bila - platform
	if ((poz[0].x == poz[7].x) && (poz[0].y < 20) && (poz[0].y > 14))
		directie = 1;
	else if ((poz[0].x < poz[7].x - 0.5) && (poz[0].x > (poz[7].x - lungime_platforma/2)) && (poz[0].y < 15)) {
		directie = 2;
	}
	else if ((poz[0].x > poz[7].x + 0.5) && (poz[0].x < (poz[7].x + lungime_platforma / 2)) && (poz[0].y < 15)) {
		directie = 3;
	}

	//bila - caramizi	
	CollisionBrick();

	//bila - subsol (pierde o viata)
	if (((poz[0].x < (poz[7].x - lungime_platforma/2)) || (poz[0].x > (poz[7].x + lungime_platforma/2))) && (poz[0].y < 15)) {
		poz[0].x = poz[7].x;
		poz[0].y = 5;
		nr_vieti_panda--;
		click = 0;
		Mat image;

		if (nr_vieti_panda == 4) {
			image = imread("C:\\Users\\Valentina\\Downloads\\ScaryClown.jpg", 1);
		}

		if (nr_vieti_panda == 2) {
			image = imread("C:\\Users\\Valentina\\Downloads\\scaryclown1.jpg", 1);
		}

		if (nr_vieti_panda == 1) {
			image = imread("C:\\Users\\Valentina\\Downloads\\scaryimg.jpg", 1);
		}

		if ((nr_vieti_panda == 4) || (nr_vieti_panda == 2) || (nr_vieti_panda == 1)) {
			if (image.empty())
			{
				cout << "Could not open or find the image" << endl;
				cin.get(); 
			}
			String windowName = "Scary image"; //Name of the window

			namedWindow(windowName); // Create a window
		

			imshow(windowName, image); // Show our image inside the created window.

			PlaySound(TEXT("C:\\aww.wav"), NULL, SND_FILENAME | SND_ASYNC);

			waitKey(0); // Wait for any keystroke in the window

			destroyWindow(windowName); //destroy the created win*/
		}
		
	}
	
}

void iTECpanda::Update(float deltaTimeSeconds) {

	
	float raport = abs((poz[7].x - poz[0].x) / lungime_platforma);

	if (click == 1) {

		Collision();
	//	cout << poz[0].x << " "<< poz[0].y << endl;
		if (directie == 1) {
				poz[0].y += speedY * deltaTimeSeconds;	
		}
		else if (directie == -1){
				poz[0].y -= speedY * deltaTimeSeconds;
				poz[0].x -= poz[0].x * deltaTimeSeconds;
		}
		else if (directie == 2) {
				poz[0].y += speedY * deltaTimeSeconds;
				poz[0].x -= raport*speedX * deltaTimeSeconds;
		}
		else if (directie == 3) {
				poz[0].y += speedY * deltaTimeSeconds;
				poz[0].x += raport*speedX * deltaTimeSeconds;
		}
		else if (directie == -2) {
			poz[0].y += speedY * deltaTimeSeconds;
			poz[0].x += speedX * deltaTimeSeconds;
		}
		else if (directie == -3) {
			poz[0].y += speedY * deltaTimeSeconds;
			poz[0].x -= speedX * deltaTimeSeconds;
		}
		
	}

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 11; j++) {

			float px, py;
			rectangleWidth = 35;
			rectangleHeight = 17.5;
			name = "caramida" + nr[i] + nr[j];	
			modelMatrix = glm::mat3(1);
			RenderMesh2D(meshes[name], shaders["VertexColor"], modelMatrix);
		}

	int index;

	index = 7 + (linie * 11 + coloana);
	if ((linie < 20) && (coloana < 20)) {

		if (patratY > 0) {

			if (angle > 6.3)
				angle = 0;
			else
				angle += (4 * deltaTimeSeconds);
			patratY -= speedY * deltaTimeSeconds;
			modelMatrix = glm::mat3(1);
			modelMatrix *= Transform2D::Translate(patratX, patratY);
			modelMatrix *= Transform2D::Rotate(angle);
			RenderMesh2D(meshes["powerUp"], shaders["VertexColor"], modelMatrix);
		}

	}

	modelMatrix = glm::mat3(1);
	RenderMesh2D(meshes["pereteStanga"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	RenderMesh2D(meshes["pereteSus"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	RenderMesh2D(meshes["pereteDreapta"], shaders["VertexColor"], modelMatrix);

	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(poz[7].x, 0);
	RenderMesh2D(meshes["platforma"], shaders["VertexColor"], modelMatrix);
	//desenare bile
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(poz[0].x, poz[0].y);
	RenderMesh2D(meshes["circle"], shaders["VertexColor"], modelMatrix);
	if (nr_vieti_panda > 0) {
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["eyeLeft"], shaders["VertexColor"], modelMatrix);
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["eyeRight"], shaders["VertexColor"], modelMatrix);
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["capPanda"], shaders["VertexColor"], modelMatrix);
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["urL"], shaders["VertexColor"], modelMatrix);
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["urR"], shaders["VertexColor"], modelMatrix);
		
	}
	if (nr_vieti_panda > 1) {
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["cerc1"], shaders["VertexColor"], modelMatrix);
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["cerc2"], shaders["VertexColor"], modelMatrix);
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["corpPanda"], shaders["VertexColor"], modelMatrix);	
	}
	if (nr_vieti_panda > 2) {
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["manaStanga"], shaders["VertexColor"], modelMatrix);
	}
	if (nr_vieti_panda > 3) {
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["manaDreapta"], shaders["VertexColor"], modelMatrix);
	}
	if (nr_vieti_panda > 4) {
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["piciorStang"], shaders["VertexColor"], modelMatrix);
	}
	if (nr_vieti_panda > 5) {
		modelMatrix = glm::mat3(1);
		RenderMesh2D(meshes["piciorDrept"], shaders["VertexColor"], modelMatrix);
	}

	if (nr_vieti_panda == 0) {
		nr_vieti_panda = 6;
		cout << "A murit ursul panda :(" << endl;
		Init();
	}

	if (nr_bricks_deleted == 80) {
		Init();
		nr_bricks_deleted = 0;
	}

}

void iTECpanda::FrameEnd()
{
	

}

void iTECpanda::OnInputUpdate(float deltaTime, int mods)
{

}

void iTECpanda::OnKeyPress(int key, int mods)
{
	// add key press event
}

void iTECpanda::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void iTECpanda::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	
	if (poz[0].y <= 5)
		poz[0].x += deltaX;

	poz[7].x += deltaX;

	//cout << poz[7].x << endl;
}

void iTECpanda::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	click = 1;
	directie = 1;
}

void iTECpanda::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void iTECpanda::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void iTECpanda::OnWindowResize(int width, int height)
{
}